create function lockrow(text, text, text, timestamp without time zone) returns integer
    strict
    language sql
as
$$ SELECT LockRow(current_schema(), $1, $2, $3, $4); $$;

comment on function lockrow(text, text, text, timestamp) is 'args: a_table_name, a_row_key, an_auth_token, expire_dt - Sets lock/authorization for a row in a table.';

alter function lockrow(text, text, text, timestamp) owner to admin;

